import argparse
import shutil
import time
from pathlib import Path
from sys import platform
import copy
import numpy as np

from models import *
from utils import torch_utils
from utils.datasets import *
from utils.utils import *


def detect(
        cfg,
        weights,
        images,
        data_cfg,
        output='output',  # output folder
        img_size=416,
        conf_thres=0.35,
        nms_thres=0.45,
        save_txt=False,
        save_images=True,
        webcam=False
):
    device = torch_utils.select_device()    # CUDA 0
    if os.path.exists(output):
        shutil.rmtree(output)  # 删除output文件夹
    os.makedirs(output + "/clip")  # 新建output文件夹

    # Initialize model
    model = Darknet(cfg, img_size)      # 模型和参数初始化

    # Load weights(对应.pt或.weight)
    if weights.endswith('.pt'):  # pytorch format
        if weights.endswith('yolov3.pt') and not os.path.exists(weights):
            if (platform == 'darwin') or (platform == 'linux'):
                os.system('wget https://storage.googleapis.com/ultralytics/yolov3.pt -O ' + weights)
        model.load_state_dict(torch.load('weights/best.pt', map_location='cpu')['model'])
    else:  # darknet format
        _ = load_darknet_weights(model, weights)    # 对应模型,导入网络权重
    model.to(device).eval()     # 测试模式(dropout和batch normalization的操作在训练和测试时不一样)
    # Set Dataloader
    if webcam:
        save_images = False
        dataloader = LoadWebcam(img_size=img_size)
    else:
        dataloader = LoadImages(images, img_size=img_size)  # 初始化dataloader，包括路径、文件数、（网路设定的）图像大小
    # Get classes and colors，得到颜色对，每一种类别，对应一个颜色
    classes = load_classes(parse_data_cfg(data_cfg)['names'])   # TODO 迁移学习记得改
    colors = [[random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)] for _ in range(len(classes))]
    detect_picture = []
    library_picture = []
    for i, (path, img, im0) in enumerate(dataloader):
        type = ""
        if  ".0.jpg" in path:
            type = "detect"
        else:
            type = "library"

        t = time.time()
        if webcam:
            print('webcam frame %g: ' % (i + 1), end='')
        else:
            print('image %g/%g %s: ' % (i + 1, len(dataloader), path), end='')
            #print(path)
        pic_name = path
        save_path = str(Path(output) / Path(path).name)     # 输出目录

        # Get detections
        img = torch.from_numpy(img).unsqueeze(0).to(device)   # 添加batch维度：1*3*416*416，并由numpy数组转换为tensor
        if ONNX_EXPORT:
            torch.onnx.export(model, img, 'weights/model.onnx', verbose=True)
            return
        pred = model(img)   # pred：[batch, 10647, 85]
        pred = pred[pred[:, :, 4] > conf_thres]  # 去掉 conf < threshold 的bbox ——>[14,85]
        have_clip = False
        pictuce = []
        temp = []
        temp2 = []
        pictuce.append(pic_name)
        pictuce.append(type)
        if len(pred) > 0:   # 若有目标
            # Run NMS on predictions,非极大值抑制NMS
            part = []
            pictuce.append(pred.cpu().numpy().tolist())
            detections = non_max_suppression(pred.unsqueeze(0), conf_thres, nms_thres)[0]   # [14,85]——>[3,7] 7为：4个位置,bbox_conf,类得分,哪一类M YOU
            # 将bbox位置从416*416映射回原始大小和比例下的位置
            scale_coords(img_size, detections[:, :4], im0.shape).round()
            # Print results to screen：1 bicycles, 1 trucks, 1 dogs
            unique_classes = detections[:, -1].cpu().unique()   # 挑出类别索引
            for c in unique_classes:
                n = (detections[:, -1].cpu() == c).sum()  # 几个
                print('%g %ss' % (n, classes[int(c)]), end=', ') # 几个什么
            count = 0
            raw_im0 = copy.deepcopy(im0)
            # Draw bounding boxes and labels of detections
            for x1, y1, x2, y2, conf, cls_conf, cls in detections:
                Lable = classes[int(cls)]
                part.append(Lable)
                if save_txt:  # Write to file
                    with open(save_path + '.txt', 'a') as file:
                        file.write('%g %g %g %g %g %g\n' %
                                   (x1, y1, x2, y2, cls, cls_conf * conf))
                count += 1
                if type == "detect":
                    area = (x2 - x1) * (y2 - y1)
                    temp.append({"picture_name": pic_name, "class": Lable, "area": int(area)})
                # Clip box
                img_clip = raw_im0[int(y1):int(y2), int(x1):int(x2)]
                save_path2 = "{}/clip/{}_{:0>2d}_{}{}".format(
                    output,
                    os.path.splitext(Path(path).name)[0],
                    count,
                    classes[int(cls)],
                    os.path.splitext(Path(path).name)[1]
                )
                # cv2.imshow('clip', img_clip)
                cv2.waitKey(0)
                cv2.imwrite(save_path2, img_clip)
                # Add bbox to the image
                label = '%s %.2f' % (classes[int(cls)], conf)
                plot_one_box([x1, y1, x2, y2], im0, label=label, color=colors[int(cls)])    # 画框，暂存到im0
            temp = sorted(temp,key=lambda x: x["area"])
            for e in temp:
                temp2.append(e["class"])
            pictuce.append(part)
        dt = time.time() - t
        print('Done. (%.3fs)' % dt)


        #print(pictuce)
        if type == "detect":
            pictuce.append(temp2)
            detect_picture.append(pictuce)
        if type == "library":
            library_picture.append(pictuce)
        if save_images:  # Save generated image with detections
            cv2.imwrite(save_path, im0)
        if have_clip:
            cv2.imwrite('./outClip', img_clip)
        # if webcam:  # Show live webcam
            # cv2.imshow(weights, im0)
    res = get_similar_pictures(detect_picture, library_picture, classes)
    print("res")
    print(res)
    if save_images and (platform == 'darwin'):  # linux/macos
        os.system('open ' + output + ' ' + save_path)

def cos_sim(vector_a, vector_b):
    """
    计算两个向量之间的余弦相似度
    :param vector_a: 向量 a
    :param vector_b: 向量 b
    :return: sim
    """
    vector_a = np.mat(vector_a)
    vector_b = np.mat(vector_b)
    num = float(vector_a * vector_b.T)
    denom = np.linalg.norm(vector_a) * np.linalg.norm(vector_b)
    cos = num / denom
    sim = 0.5 + 0.5 * cos
    return sim

def get_similar_pictures(detect_pictures, library_pictures, classes):
    part1 = []
    part2 = []
    part3 = []
    part4 = []
    part5 = []
    part6 = []
    part7 = []
    part8 = []
    part9 = []
    part10 = []
    part11 = []
    part12 = []
    result = []

    for pic in library_pictures:
        pic_name = pic[0]
        pic_type = pic[1]
        if len(pic) == 2:
            continue
        if len(pic) == 3:
            continue
        vectors = pic[2]
        if len(vectors) == 0:
            continue
        parts = pic[3]
        if len(parts) == 0:
            continue
        for vector in vectors:
            i = 0
            part = parts[i]
            index = classes.index(part)
            local_part = []
            local_part.append(pic_name)
            local_part.append(pic_type)
            local_part.append(part)
            local_part.append(vector)
            if index == 0:
                part1.append(local_part)
            if index == 1:
                part2.append(local_part)
            if index == 2:
                part3.append(local_part)
            if index == 3:
                part4.append(local_part)
            if index == 4:
                part5.append(local_part)
            if index == 5:
                part6.append(local_part)
            if index == 6:
                part7.append(local_part)
            if index == 7:
                part8.append(local_part)
            if index == 8:
                part9.append(local_part)
            if index == 9:
                part10.append(local_part)
            if index == 10:
                part11.append(local_part)
            if index == 11:
                part12.append(local_part)
            i = i + 1
    for picture in detect_pictures:
        picture_name = picture[0]
        picture_type = picture[1]
        if len(picture) == 2:
            continue
        vectors = picture[2]
        if len(vectors) == 0:
            continue
        parts = picture[3]
        similar_picture = []
        areas = picture[4]
        if len(areas) == 0:
            continue
        for vector in vectors:
            t = 0
            similar_pictures = []
            part = parts[t]
            index = classes.index(part)
            if index == 0:
                for pic in part1:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 1:
                for pic in part2:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 2:
                for pic in part3:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 3:
                for pic in part4:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 4:
                for pic in part5:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 5:
                for pic in part6:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 6:
                for pic in part7:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 7:
                for pic in part8:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 8:
                for pic in part9:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 9:
                for pic in part10:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 10:
                for pic in part11:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            if index == 11:
                for pic in part12:
                    pic_name = pic[0]
                    vec = pic[3]
                    tmp = {"picture_name": pic_name, "part": part,"cos_sim": cos_sim(vector, vec)}
                    similar_pictures.append(tmp)
                similar_pictures = sorted(similar_pictures, key=lambda x: x["cos_sim"])
                sp = similar_pictures[-10:]
                similar_picture.append(sp)
            t = t + 1

        res = []
        if len(picture[4]) == 1:
            for t in similar_picture:
                for e in t:
                    if e["part"] == picture[4][0]:
                        res.append({"picture_name": e["picture_name"], "cos_sim": e["cos_sim"]})

        if len(picture[4]) == 2:
            l1 = 0.6
            l2 = 0.4
            for t in similar_picture:
                for e in t:
                    if e["part"] == picture[4][1]:
                        res.append({"picture_name": e["picture_name"], "cos_sim": e["cos_sim"] * l1})
                    else:
                        res.append({"picture_name": e["picture_name"], "cos_sim": e["cos_sim"] * l2})

        if len(picture[4]) >= 3:
            l1 = 0.6
            l2 = 0.2
            l3 = 0.2
            for t in similar_picture:
                for e in t:
                    if e["part"] == picture[4][0]:
                        res.append({"picture_name": e["picture_name"], "cos_sim": e["cos_sim"] * l2})
                    if e["part"] == picture[4][1]:
                        res.append({"picture_name": e["picture_name"], "cos_sim": e["cos_sim"] * l3})
                    if e["part"] == picture[4][2]:
                        res.append({"picture_name": e["picture_name"], "cos_sim": e["cos_sim"] * l1})
        res = sorted(res, key=lambda x: x["cos_sim"])
        result.append((picture_name, res[-10:]))
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg', type=str, default='cfg/yolov3.cfg', help='cfg文件路径')
    parser.add_argument('--data_cfg', type=str, default='data2/test.data', help='coco.data file path')
    parser.add_argument('--weights', type=str, default='weights/best.pt', help='权重文件路径')    # TODO 改
    parser.add_argument('--images', type=str, default='data2/samples', help='path to images')
    parser.add_argument('--img-size', type=int, default=32 * 13, help='size of each image dimension')
    parser.add_argument('--conf-thres', type=float, default=0.35, help='object confidence threshold')
    parser.add_argument('--nms-thres', type=float, default=0.35, help='iou threshold for non-maximum suppression')
    opt = parser.parse_args()
    print(opt)

    with torch.no_grad():
        detect(
            opt.cfg,
            opt.weights,
            opt.images,
            opt.data_cfg,
            img_size=opt.img_size,
            conf_thres=opt.conf_thres,
            nms_thres=opt.nms_thres
        )
