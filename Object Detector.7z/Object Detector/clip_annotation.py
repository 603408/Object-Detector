import os
import xml.dom.minidom
from xml.etree import ElementTree as ET
import cv2

xml_path = 'clip_annotation/annotation'
pic_path = 'clip_annotation/image'

count = 0
s = {}
# 对xml文件和图片文件进行排序，不排序可能导致图片和xml文件对应不上
xml_files = os.listdir(xml_path)
xml_files.sort()
pic_files = os.listdir(pic_path)
pic_files.sort()

for xmlFile in xml_files:
    if not os.path.isdir(xmlFile):
        print(xmlFile)
    # 找到xml文件中的bndbox属性
    if xmlFile.endswith('.xml'):
        per = ET.parse(os.path.join(xml_path, xmlFile))
        p_value = per.findall('./object/bndbox')
        # 获得完整xml中的bndbox的路径
        dom = xml.dom.minidom.parse(os.path.join(xml_path, xmlFile))
        root = dom.documentElement
        # 通过元素名获取name的属性值
        xml_name = root.getElementsByTagName('name')
        # xml_object = root.getElementByTagName('object')
        # 这里case实际为name的第一个child_data
        with open('tags.txt','r') as f:
            lines = f.read().splitlines()

        for i in range(len(xml_name)):
            if xml_name[i].firstChild.data in lines:
                values = p_value[i].getchildren()
                # 获取坐标值
                for child in values:
                    s[child.tag] = child.text
                # 分别将四个点的坐标赋值给四个变量
                x_min = dict.get(s, 'xmin')
                y_min = dict.get(s, 'ymin')
                x_max = dict.get(s, 'xmax')
                y_max = dict.get(s, 'ymax')
                # 处理图片
                for bmpFile in pic_files:
                    if not os.path.isdir(bmpFile):
                        print(bmpFile)
                        print("==============================")

                    # img = cv2.imread(pic_path + '/' + '000' + str(count) + '.jpg')
                    # # 根据获得的xml中的坐标信息裁剪图片
                    # crop = img[int(y_min):int(y_max), int(x_min):int(x_max)]
                    # # 裁剪完成，写入图像
                    # cv2.imwrite('./clip_annotation/result/' + '00' + str(count) + '.jpg', crop)

                    if bmpFile.endswith('.jpg'):
                        if count < 566:
                            # 读取图片
                            img = cv2.imread(pic_path + '/' + 'A ' + '(' + str(count+1) + ')'+'.jpg')
                            # 根据获得的xml中的坐标信息裁剪图片
                            crop = img[int(y_min):int(y_max), int(x_min):int(x_max)]
                            # 裁剪完成，写入图像
                            cv2.imwrite('./clip_annotation/result/' + 'A' + str(count+1) + str(xml_name) + '.jpg', crop)

                        elif 566 <= count < 1130:
                            # 读取图片
                            img = cv2.imread(pic_path + '/' + 'B ' + '(' + str(count + 1) + ')' + '.jpg')
                            # 根据获得的xml中的坐标信息裁剪图片
                            crop = img[int(y_min):int(y_max), int(x_min):int(x_max)]
                            # 裁剪完成，写入图像
                            cv2.imwrite('./clip_annotation/result/' + 'B' + str(count + 1) + str(xml_name) + '.jpg', crop)
                        else:
                            # 读取图片
                            img = cv2.imread(pic_path + '/' + 'C ' + '(' + str(count + 1) + ')' + '.jpg')
                            # 根据获得的xml中的坐标信息裁剪图片
                            crop = img[int(y_min):int(y_max), int(x_min):int(x_max)]
                            # 裁剪完成，写入图像
                            cv2.imwrite('./clip_annotation/result/' + 'C' + str(count + 1) + str(xml_name) + '.jpg', crop)
                        count += 1
                    break
