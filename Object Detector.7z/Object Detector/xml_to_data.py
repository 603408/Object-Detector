
import random
import xml.etree.ElementTree as ET
import os
import cv2

#classes = ['fanlian','lian','ju','mei','mudan','yulan','jiaoye','song','lingzhi','ruyi','fu','taihushi','tao','zhu','lanhua','shiliu','hulu','que','long','xinglong','die','feng'] 2023.12.8
classes = ['fanlian','lian','ju','mei','mudan','yulan','jiaoye','song','lingzhi','ruyi','fu','taihushi','tao','zhu','lanhua','shiliu','hulu','que','long','xinglong','die','feng'] #2023.12.9

def convert(size, box):
    dw = 1. / size[0]
    dh = 1. / size[1]
    x = (box[0] + box[1]) / 2.0
    y = (box[2] + box[3]) / 2.0
    w = box[1] - box[0]
    h = box[3] - box[2]
    x = x * dw
    w = w * dw
    y = y * dh
    h = h * dh
    return (x, y, w, h)


def convert_annotation(data_folder ,image_id):
    in_file = open( 'data2/Annotations/%s.xml' % (image_id), encoding='utf-8')      # 输入路径
    in_img = 'data2/images/%s.jpg' % image_id      # input image
        # 输出路径
    tree = ET.parse(in_file)
    root = tree.getroot()
    size = root.find('size')
    w = int(size.find('width').text)
    h = int(size.find('height').text)
    
    if root.find('object') is not None:
        if not os.path.exists('data2/labels'):
            os.mkdir( 'data2/labels')
        if not os.path.exists('data2/clips'):
            os.mkdir('data2/clips')
        out_file = open( 'data2/labels/%s.txt' % (image_id), 'w', encoding='utf-8')
        count = 0

        for obj in root.iter('object'):
            cls = obj.find('name').text
            if cls not in classes:
                continue
            cls_id = classes.index(cls)
            xmlbox = obj.find('bndbox')
            b = (float(xmlbox.find('xmin').text), float(xmlbox.find('xmax').text), float(xmlbox.find('ymin').text),
                float(xmlbox.find('ymax').text))
            bb = convert((w, h), b)
            out_file.write(str(cls_id) + " " + " ".join([str(a) for a in bb]) + '\n')
            
            
            img = cv2.imread(in_img, 1)
            clip = img[int(xmlbox.find('ymin').text):int(xmlbox.find('ymax').text), int(xmlbox.find('xmin').text):int(xmlbox.find('xmax').text)]
            #cv2.imshow('imshow',clip)
            #cv2.waitKey(0)
            count += 1
            clip_file = '{}/clips/{}_{:0>2d}_{}.jpg'.format(data_folder, image_id, count, cls)
            print(clip_file)
            cv2.imwrite(clip_file, clip)
            
            
        return image_id
    

def filter_data(data_folder):
    print('========')
    print(data_folder)
    xmlfilepath = 'data2/Annotations/'
    # xmlfilepath =  'data2/Annotations/'
    total_xml = os.listdir(xmlfilepath)
    print(total_xml)

    data_with_labels = open('data2/data_with_labels.txt', 'w', encoding='utf-8')
    for image_file_name in total_xml:
        # 去掉.xml后缀 -4
        image_id = image_file_name[:-4]
        print(image_id)
        temp = convert_annotation(data_folder, image_id)
        if temp is not None:
            data_with_labels.write(temp + '\n')
    data_with_labels.close()

def modify_XML_labels(path_prefix ,xml_label_lv1, xml_label_lv2, xml_value_pre, xml_value):
    filenames = os.listdir(path_prefix)
    # print(filenames)
    for filename in filenames:
        
        # print(filename)
        tree = ET.parse(path_prefix + filename)
        root = tree.getroot()

        for object_tree in root.findall(xml_label_lv1):
            
            name_tag = object_tree.find(xml_label_lv2)
            if name_tag.text == xml_value_pre:
                name_tag.text = xml_value
            print(name_tag.text)
        tree.write(path_prefix + filename, encoding='utf-8', xml_declaration=True)


def split_data_into_train_val_test(data_folder, trainval_percent, train_percent):
    image_ids = open('data2/data_with_labels.txt').read().strip().split()
    # print(image_ids)

    data_num = len(image_ids)
    data_indices = range(data_num)
    tv = int(data_num * trainval_percent)
    tr = int(tv * train_percent)

    trainval = random.sample(data_indices, tv)
    train = random.sample(trainval, tr)

    ftrainval = open('data2/trainval.txt', 'w')
    ftest = open( 'data2/test.txt', 'w')
    ftrain = open( 'data2/train.txt', 'w')
    fval = open(  'data2/val.txt', 'w')

    for i in data_indices:
        image_id = image_ids[i]
        # print("!!!!!!!!!!!!!!!!!!!!")
        print('-' + image_id)
        if i in trainval:
            ftrainval.write('data2/images/%s.jpg\n' % (image_id))
            if i in train:
                ftest.write('data2/images/%s.jpg\n' % (image_id))
            else:
                fval.write('data2/images/%s.jpg\n' % (image_id))
        else:
            ftrain.write('data2/images/%s.jpg\n' % (image_id))
        
    ftrainval.close()
    ftrain.close()
    fval.close()
    ftest.close()


# modify_XML_labels('data2/Annotations/', 'object', 'name', 'tiger1', 'tiger')

trainval_percent = 0.1
train_percent = 0.9
filter_data('data2')
split_data_into_train_val_test('data2', trainval_percent, train_percent)